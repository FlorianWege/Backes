package core;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.Collections;

public class Level {
    private final boolean[][] _switchMap;
    private final int[][] _heightMap;

    public int getHeight() {
        return _switchMap.length;
    }

    public int getWidth() {
        return _switchMap[0].length;
    }

    @Nonnull
    public boolean[][] getSwitchMap() {
        return _switchMap.clone();
    }

    @Nonnull
    public int[][] getHeightMap() {
        return _heightMap.clone();
    }

    public Level(@Nonnull boolean[][] switchMap, @Nonnull int[][] heightMap) {
        _switchMap = switchMap;
        _heightMap = heightMap;
    }
}
