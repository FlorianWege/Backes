package core;

import javafx.util.Pair;

import javax.annotation.Nonnull;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;

public class LevelRun {
    private final Level _level;
    private final RobotAlgo _algo;

    private final Set<Pair<Integer, Integer>> _remainingSwitches = new LinkedHashSet<>();

    private int _curX;
    private int _curY;
    private int _dir;
    private boolean _started = false;
    private boolean _over = false;

    public interface ActionHandler {
        void result(boolean success);
    }

    private final ActionHandler _actionHandler;

    public void finish(boolean success) {
        if (_over) return;

        _over = true;

        _actionHandler.result(success);
    }

    /*
    * y ^
    *   |
    *   |S
    *   |
    *    - - - >
    *          x
    *
    *   S = start
     */

    private void moveForward(boolean jump) {
        int newX = _curX;
        int newY = _curY;

        switch (_dir) {
            case 0:
                // right
                if (newX < _level.getWidth() - 1) newX++;

                break;
            case 1:
                // up
                if (newY < _level.getHeight() - 1) newY++;

                break;
            case 2:
                // left
                if (newX > 0) newX--;

                break;
            case 3:
                // down
                if (newY > 0) newY--;

                break;
        }

        if (jump || _level.getHeightMap()[newY][newX] == _level.getHeightMap()[_curY][_curX]) {
            _curX = newX;
            _curY = newY;
        }
    }

    private void applyAction(@Nonnull RobotAction action) {
        RobotAction.Type actionType = action.getType();

        switch (actionType) {
            case ROTATE_LEFT:
                _dir = _dir == 3 ? 0 : _dir + 1;

                break;
            case ROTATE_RIGHT:
                _dir = _dir == 0 ? 3 : _dir - 1;

                break;
            case MOVE:
                moveForward(false);

                break;
            case JUMP:
                moveForward(true);

                break;
            case SWITCH:
                if (_remainingSwitches.remove(new Pair<>(_curX, _curY))) {
                    if (_remainingSwitches.isEmpty()) {
                        finish(true);
                    }
                }

                break;
            case F1:
                startGroup(_algo.getF1Group());

                break;
            case F2:
                startGroup(_algo.getF2Group());

                break;
        }
    }

    private void startGroup(@Nonnull RobotAlgo.Group group) {
        for (RobotAction action : group.getActions()) {
            if (_over) break;

            applyAction(action);
        }
    }

    private void startAlgo(@Nonnull RobotAlgo algo) {
        startGroup(algo.getMainGroup());

        finish(false);
    }

    public void run() {
        if (_started) throw new IllegalStateException("already started");

        _started = true;

        startAlgo(_algo);
    }

    public LevelRun(@Nonnull Level level, @Nonnull RobotAlgo algo, @Nonnull ActionHandler actionHandler) {
        _level = level;
        _algo = algo;
        _actionHandler = actionHandler;

        _curX = 0;
        _curY = level.getHeight() / 2;
        _dir = 0;

        boolean[][] switchMap = level.getSwitchMap();

        for (int x = 0; x < _level.getWidth(); x++) {
            for (int y = 0; y < _level.getHeight(); y++) {
                if (switchMap[y][x]) {
                    System.out.println("add " + new Pair<>(x, y));
                    _remainingSwitches.add(new Pair<>(x, y));
                }
            }
        }
    }
}
