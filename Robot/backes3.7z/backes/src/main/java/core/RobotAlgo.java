package core;

import javax.annotation.Nonnull;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RobotAlgo {
    public class Group {
        private final List<RobotAction> _action = new ArrayList<>();

        @Nonnull
        public List<RobotAction> getActions() {
            return _action;
        }

        public void addAction(@Nonnull RobotAction action) {
            _action.add(action);
        }

        public Group() {

        }
    }

    private final Group _mainGroup = new Group();
    private final Group _f1Group = new Group();
    private final Group _f2Group = new Group();

    public Group getMainGroup() {
        return _mainGroup;
    }

    public Group getF1Group() {
        return _f1Group;
    }

    public Group getF2Group() {
        return _f2Group;
    }

    public RobotAlgo() {

    }

    public RobotAlgo(@Nonnull String[] mainGroupActions, @Nonnull String[] f1GroupActions, @Nonnull String[] f2GroupActions) {
        for (String actionS : mainGroupActions) {
            _mainGroup.addAction(new RobotAction(actionS));
        }
        for (String actionS : f1GroupActions) {
            _f1Group.addAction(new RobotAction(actionS));
        }
        for (String actionS : f2GroupActions) {
            _f2Group.addAction(new RobotAction(actionS));
        }
    }

    public RobotAlgo(@Nonnull File file) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));

        String line;

        while ((line = reader.readLine()) != null) {
            Pattern pattern = Pattern.compile("(\\w+):([\\w\\s]+)$");

            Matcher matcher = pattern.matcher(line);

            if (matcher.find()) {
                String groupS = matcher.group(1);
                String actionLine = matcher.group(2);

                Group group = null;

                switch (groupS) {
                    case "main":
                        group = _mainGroup;

                        break;
                    case "f1":
                        group = _f1Group;

                        break;
                    case "f2":
                        group = _f2Group;

                        break;
                }

                if (group == null) throw new IllegalArgumentException("invalid group " + groupS);

                actionLine = actionLine.trim();

                actionLine = actionLine.replaceAll("\\s+", ";");

                String[] actionsS = actionLine.split(";");

                for (String actionS : actionsS) {
                    group.addAction(new RobotAction(actionS));
                }
            }
        }

        reader.close();
    }
}
