package misc;

import com.sun.jndi.toolkit.url.Uri;
import core.RobotAlgo;
import org.testng.annotations.Test;

import javax.annotation.Nonnull;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AlgoTest {
    @Test()
    public void Test() throws IOException {
        String pathS = "RobotAlgos/ExampleAlgo.txt";

        URL url = getClass().getClassLoader().getResource(pathS);

        assert url != null : pathS + " not found";

        new RobotAlgo(new File(url.getFile()));
    }
}
