package misc;

import core.Level;
import core.LevelRun;
import core.RobotAction;
import core.RobotAlgo;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;

public class LevelRunTest {
    @Test()
    public void Test() {
        boolean switchMap[][] = new boolean[][] {
                {false, false, false, false, false},
                {false, false, false, false, false},
                {false, false, false, false, true},
                {false, false, false, false, false},
                {false, false, false, false, false},
        };

        int heightMap[][] = new int[][] {
                {0, 1, 0, 0, 0},
                {0, 1, 0, 0, 0},
                {0, 1, 0, 0, 0},
                {0, 0, 0, 0, 0},
                {0, 1, 0, 0, 0}
        };

        //TODO: matrix is vertically inverted

        Level level = new Level(switchMap, heightMap);

        RobotAlgo algo = new RobotAlgo(new String[]{"l", "m", "r", "m", "1", "2"}, new String[]{"m", "m", "m"}, new String[]{"r", "m", "s"});

        algo.getMainGroup().addAction(new RobotAction(RobotAction.Type.ROTATE_LEFT));

        final boolean[] fail = {true};

        LevelRun levelRun = new LevelRun(level, algo, success -> fail[0] = !success);

        levelRun.run();

        Assert.assertTrue(!fail[0]);
    }
}
